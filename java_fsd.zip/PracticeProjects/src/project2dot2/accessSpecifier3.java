package project2dot2;

import project2dot1.*;
public class accessSpecifier3 extends proaccessspecifiers {
	
	public static void main(String[] args) {
		accessSpecifier3 obj = new accessSpecifier3 ();
	obj.display();
	}
	
}
